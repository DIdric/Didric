export const colors = {
  background: '#161616',
  white: '#FFFFFF',
  accent: {
    red: '#FF0600',
    cyan: '#E80066',
    purple: '#9F2BFF',
    blue: '#146BFF'
  }
} as const;