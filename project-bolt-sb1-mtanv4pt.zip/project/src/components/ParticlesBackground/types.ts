export interface Vector {
  x: number;
  y: number;
}