export const MENU_ITEMS = [
  { label: 'Home', id: 'home', href: '/' },
  { label: 'Projects', id: 'projects', href: '/#projects' }, // Changed from /projects to /#projects
  { label: 'About', id: 'about', href: '/#about' },
  { label: 'Contact', id: 'contact', href: '/#contact' },
] as const;