import React from 'react';
import { useProfile } from '../../hooks/useProfile';
import ProjectForm from '../../components/admin/ProjectForm';
import { useProjects } from '../../hooks/useProjects';
import { Pencil, Trash2 } from 'lucide-react';

export default function Dashboard() {
  const { projects, isLoading } = useProjects();
  const [editingProject, setEditingProject] = React.useState<string | null>(null);

  if (isLoading) {
    return <div className="p-8">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-dark-900 text-white p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-8 bg-gradient-accent bg-clip-text text-transparent">
          Content Management
        </h1>

        <div className="space-y-8">
          {/* Projects Section */}
          <section>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-semibold">Projects</h2>
              <button
                onClick={() => setEditingProject('new')}
                className="px-4 py-2 bg-accent-blue rounded-lg hover:bg-opacity-80 transition-colors"
              >
                Add Project
              </button>
            </div>

            {editingProject && (
              <div className="mb-8 p-6 bg-dark-800 rounded-lg">
                <ProjectForm
                  projectId={editingProject === 'new' ? undefined : editingProject}
                  onSuccess={() => setEditingProject(null)}
                />
              </div>
            )}

            <div className="grid gap-4">
              {projects?.map((project) => (
                <div
                  key={project.id}
                  className="p-4 bg-dark-800 rounded-lg flex items-center justify-between"
                >
                  <div>
                    <h3 className="font-medium">{project.title}</h3>
                    <p className="text-sm text-gray-400">{project.description}</p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setEditingProject(project.id)}
                      className="p-2 hover:bg-dark-700 rounded-lg transition-colors"
                    >
                      <Pencil className="w-4 h-4" />
                    </button>
                    <button className="p-2 hover:bg-dark-700 rounded-lg transition-colors text-red-500">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}