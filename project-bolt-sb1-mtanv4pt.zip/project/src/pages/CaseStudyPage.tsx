import { useParams, useNavigate } from 'react-router-dom';
import { CaseStudyLayout } from '../components/case-study/CaseStudyLayout';
import { CaseStudyHeader } from '../components/case-study/CaseStudyHeader';
import { CaseStudyContent } from '../components/case-study/CaseStudyContent';
import { CaseStudyStats } from '../components/case-study/CaseStudyStats';
import { Button } from '../components/ui/Button';
import { useCaseStudies } from '../hooks/useCaseStudies';
import ReactMarkdown from 'react-markdown';

export function CaseStudyPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { caseStudies, isLoading } = useCaseStudies();
  const caseStudy = caseStudies?.find(study => study.id === id);

  if (isLoading) {
    return (
      <CaseStudyLayout>
        <div className="animate-pulse space-y-8">
          <div className="h-8 bg-dark-800 rounded w-1/4" />
          <div className="aspect-video bg-dark-800 rounded" />
          <div className="space-y-4">
            <div className="h-4 bg-dark-800 rounded w-3/4" />
            <div className="h-4 bg-dark-800 rounded w-1/2" />
          </div>
        </div>
      </CaseStudyLayout>
    );
  }

  if (!caseStudy) {
    return (
      <CaseStudyLayout>
        <div className="text-center py-12">
          <h1 className="text-2xl font-bold mb-4">Case Study Not Found</h1>
          <p className="text-gray-400 mb-8">
            The case study you're looking for doesn't exist or has been removed.
          </p>
          <Button onClick={() => navigate('/')}>
            Return Home
          </Button>
        </div>
      </CaseStudyLayout>
    );
  }

  return (
    <CaseStudyLayout>
      <CaseStudyHeader {...caseStudy} />
      
      {caseStudy.metrics?.length > 0 && (
        <CaseStudyStats stats={caseStudy.metrics} />
      )}
      
      <CaseStudyContent>
        <ReactMarkdown>
          {caseStudy.content}
        </ReactMarkdown>
      </CaseStudyContent>
    </CaseStudyLayout>
  );
}