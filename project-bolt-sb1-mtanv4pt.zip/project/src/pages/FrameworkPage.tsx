import { useParams, useNavigate } from 'react-router-dom';
import { CaseStudyLayout } from '../components/case-study/CaseStudyLayout';
import { CaseStudyContent } from '../components/case-study/CaseStudyContent';
import { CaseStudyStats } from '../components/case-study/CaseStudyStats';
import { Button } from '../components/ui/Button';
import { useFrameworks } from '../hooks/useFrameworks';
import ReactMarkdown from 'react-markdown';

export function FrameworkPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { frameworks, isLoading } = useFrameworks();
  const framework = frameworks?.find(f => f.id === id);

  if (isLoading) {
    return (
      <CaseStudyLayout>
        <div className="animate-pulse space-y-8">
          <div className="h-8 bg-dark-800 rounded w-1/4" />
          <div className="space-y-4">
            <div className="h-4 bg-dark-800 rounded w-3/4" />
            <div className="h-4 bg-dark-800 rounded w-1/2" />
          </div>
        </div>
      </CaseStudyLayout>
    );
  }

  if (!framework) {
    return (
      <CaseStudyLayout>
        <div className="text-center py-12">
          <h1 className="text-2xl font-bold mb-4">Framework Not Found</h1>
          <p className="text-gray-400 mb-8">
            The framework you're looking for doesn't exist or has been removed.
          </p>
          <Button onClick={() => navigate('/')}>
            Return Home
          </Button>
        </div>
      </CaseStudyLayout>
    );
  }

  return (
    <CaseStudyLayout>
      <div className="space-y-12">
        <header>
          <h1 className="text-4xl font-bold text-white mb-6">{framework.title}</h1>
          <p className="text-xl text-gray-400">{framework.description}</p>
        </header>

        {framework.metrics?.length > 0 && (
          <CaseStudyStats stats={framework.metrics} />
        )}

        <CaseStudyContent>
          <ReactMarkdown>
            {framework.content}
          </ReactMarkdown>
        </CaseStudyContent>
      </div>
    </CaseStudyLayout>
  );
}