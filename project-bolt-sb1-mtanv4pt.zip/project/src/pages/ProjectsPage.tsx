import { MainLayout } from '../components/layout/MainLayout';
import { ProjectsSection } from '../components/sections/projects/ProjectsSection';

export function ProjectsPage() {
  return (
    <MainLayout>
      <div className="pt-32">
        <ProjectsSection />
      </div>
    </MainLayout>
  );
}