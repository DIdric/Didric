import { createBrowserRouter } from 'react-router-dom';
import App from '../App';
import { CaseStudyPage } from '../pages/CaseStudyPage';
import { FrameworkPage } from '../pages/FrameworkPage';
import { AdminPage } from '../pages/admin/AdminPage';
import { NotFoundPage } from '../pages/NotFoundPage';

export const router = createBrowserRouter([
  {
    path: '/',
    element: <App />,
  },
  {
    path: '/case-studies/:id',
    element: <CaseStudyPage />,
  },
  {
    path: '/frameworks/:id',
    element: <FrameworkPage />,
  },
  {
    path: '/admin',
    element: <AdminPage />,
  },
  {
    path: '*',
    element: <NotFoundPage />,
  }
]);