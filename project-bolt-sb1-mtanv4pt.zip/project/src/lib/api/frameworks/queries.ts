import { supabase } from '../../supabase';
import type { Framework } from './types';
import { FrameworkError } from './errors';

export async function getFrameworks(): Promise<Framework[]> {
  try {
    const { data, error } = await supabase
      .from('frameworks')
      .select('*')
      .order('order_index', { ascending: true });

    if (error) throw error;
    return data || [];
  } catch (err: any) {
    throw new FrameworkError(
      'Failed to fetch frameworks',
      undefined,
      err.code
    );
  }
}

export async function getFramework(id: string): Promise<Framework | null> {
  try {
    const { data, error } = await supabase
      .from('frameworks')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error) throw error;
    return data;
  } catch (err: any) {
    if (err.code === 'PGRST116') return null;
    throw new FrameworkError(
      'Failed to fetch framework',
      undefined,
      err.code
    );
  }
}