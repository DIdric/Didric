export interface FrameworkMetric {
  label: string;
  value: string;
}

export interface Framework {
  id: string;
  user_id: string;
  title: string;
  description: string;
  content: string;
  category: string;
  metrics: FrameworkMetric[];
  order_index: number;
  created_at: string;
  updated_at: string;
}