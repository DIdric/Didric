export interface ValidationError {
  field: string;
  message: string;
}

export class FrameworkError extends Error {
  constructor(
    message: string,
    public errors?: ValidationError[],
    public code?: string
  ) {
    super(message);
    this.name = 'FrameworkError';
    Object.setPrototypeOf(this, FrameworkError.prototype);
  }
}