import { supabase } from '../../supabase';
import type { Framework } from './types';
import { FrameworkError } from './errors';
import { validateFramework } from './validation';

export async function createFramework(
  userId: string,
  data: Omit<Framework, 'id' | 'created_at' | 'updated_at' | 'user_id'>
): Promise<Framework> {
  try {
    const validationErrors = validateFramework(data);
    if (validationErrors.length > 0) {
      throw new FrameworkError('Validation failed', validationErrors);
    }

    const { data: result, error } = await supabase
      .from('frameworks')
      .insert([{
        ...data,
        user_id: userId,
        metrics: data.metrics?.filter(m => m.label && m.value) || []
      }])
      .select()
      .single();

    if (error) throw error;
    return result;
  } catch (err: any) {
    throw new FrameworkError(
      err instanceof FrameworkError ? err.message : 'Failed to create framework',
      err instanceof FrameworkError ? err.errors : undefined,
      err.code
    );
  }
}

export async function updateFramework(
  userId: string,
  frameworkId: string,
  updates: Partial<Omit<Framework, 'id' | 'created_at' | 'updated_at' | 'user_id'>>
): Promise<Framework> {
  try {
    const validationErrors = validateFramework(updates);
    if (validationErrors.length > 0) {
      throw new FrameworkError('Validation failed', validationErrors);
    }

    const { data, error } = await supabase
      .from('frameworks')
      .update({
        ...updates,
        metrics: updates.metrics?.filter(m => m.label && m.value) || [],
        updated_at: new Date().toISOString()
      })
      .eq('id', frameworkId)
      .eq('user_id', userId)
      .select()
      .single();

    if (error) throw error;
    return data;
  } catch (err: any) {
    throw new FrameworkError(
      err instanceof FrameworkError ? err.message : 'Failed to update framework',
      err instanceof FrameworkError ? err.errors : undefined,
      err.code
    );
  }
}

export async function updateFrameworkOrder(
  userId: string,
  frameworkId: string,
  newIndex: number
): Promise<void> {
  try {
    // Get current frameworks to determine order changes
    const { data: frameworks, error: fetchError } = await supabase
      .from('frameworks')
      .select('id, order_index')
      .order('order_index', { ascending: true });

    if (fetchError) throw fetchError;
    if (!frameworks) throw new Error('Failed to fetch frameworks');

    // Find current index
    const currentIndex = frameworks.findIndex(f => f.id === frameworkId);
    if (currentIndex === -1) throw new Error('Framework not found');

    // Update order_index for all affected frameworks
    const { error: updateError } = await supabase.rpc('reorder_frameworks', {
      p_framework_id: frameworkId,
      p_new_index: newIndex,
      p_user_id: userId
    });

    if (updateError) throw updateError;
  } catch (err: any) {
    throw new FrameworkError(
      'Failed to update framework order',
      undefined,
      err.code
    );
  }
}