import type { Framework } from './types';
import type { ValidationError } from './errors';

export function validateFramework(data: Partial<Framework>): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Required fields validation
  const requiredFields = {
    title: 'Title',
    category: 'Category', 
    description: 'Description',
    content: 'Content'
  } as const;

  for (const [field, label] of Object.entries(requiredFields)) {
    if (!data[field as keyof typeof requiredFields]?.toString().trim()) {
      errors.push({
        field,
        message: `${label} is required`
      });
    }
  }

  // Metrics validation
  if (data.metrics?.length) {
    data.metrics.forEach((metric, index) => {
      if (!metric.label?.trim() || !metric.value?.trim()) {
        errors.push({
          field: 'metrics',
          message: `Metric ${index + 1}: Both label and value are required`
        });
      }
    });
  }

  return errors;
}