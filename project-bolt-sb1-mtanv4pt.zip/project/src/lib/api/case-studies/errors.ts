export interface ValidationError {
  field: string;
  message: string;
}

export class CaseStudyError extends Error {
  constructor(
    message: string,
    public errors?: ValidationError[],
    public code?: string
  ) {
    super(message);
    this.name = 'CaseStudyError';
    // Ensure proper prototype chain for instanceof checks
    Object.setPrototypeOf(this, CaseStudyError.prototype);
  }
}