import { supabase } from '../../supabase';
import type { CaseStudy } from './types';
import { CaseStudyError } from './errors';
import { validateCaseStudy } from './validation';

export async function createCaseStudy(
  userId: string,
  data: Omit<CaseStudy, 'id' | 'created_at' | 'updated_at' | 'user_id'>
): Promise<CaseStudy> {
  try {
    // Validate input
    const validationErrors = validateCaseStudy(data);
    if (validationErrors.length > 0) {
      throw new CaseStudyError('Validation failed', validationErrors);
    }

    const { data: result, error } = await supabase
      .from('case_studies')
      .insert([{
        ...data,
        user_id: userId,
        metrics: data.metrics?.filter(m => m.label && m.value) || []
      }])
      .select()
      .single();

    if (error) throw error;
    return result;
  } catch (err: any) {
    throw new CaseStudyError(
      err instanceof CaseStudyError ? err.message : 'Failed to create case study',
      err instanceof CaseStudyError ? err.errors : undefined,
      err.code
    );
  }
}

export async function updateCaseStudy(
  userId: string,
  caseStudyId: string,
  updates: Partial<Omit<CaseStudy, 'id' | 'created_at' | 'updated_at' | 'user_id'>>
): Promise<CaseStudy> {
  try {
    // Validate input
    const validationErrors = validateCaseStudy(updates);
    if (validationErrors.length > 0) {
      throw new CaseStudyError('Validation failed', validationErrors);
    }

    const { data, error } = await supabase
      .from('case_studies')
      .update({
        ...updates,
        metrics: updates.metrics?.filter(m => m.label && m.value) || [],
        updated_at: new Date().toISOString()
      })
      .eq('id', caseStudyId)
      .eq('user_id', userId)
      .select()
      .maybeSingle();

    if (error) throw error;
    if (!data) throw new Error('Case study not found or access denied');

    return data;
  } catch (err: any) {
    throw new CaseStudyError(
      err instanceof CaseStudyError ? err.message : 'Failed to update case study',
      err instanceof CaseStudyError ? err.errors : undefined,
      err.code
    );
  }
}