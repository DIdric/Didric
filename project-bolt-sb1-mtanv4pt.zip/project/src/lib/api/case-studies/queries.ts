import { supabase } from '../../supabase';
import type { CaseStudy } from './types';
import { CaseStudyError } from './errors';

export async function getCaseStudies(): Promise<CaseStudy[]> {
  try {
    const { data, error } = await supabase
      .from('case_studies')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  } catch (err: any) {
    throw new CaseStudyError(
      'Failed to fetch case studies',
      undefined,
      err.code
    );
  }
}

export async function getCaseStudy(id: string): Promise<CaseStudy | null> {
  try {
    const { data, error } = await supabase
      .from('case_studies')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error) throw error;
    return data;
  } catch (err: any) {
    // Don't throw for "no rows returned" error
    if (err.code === 'PGRST116') return null;
    
    throw new CaseStudyError(
      'Failed to fetch case study',
      undefined,
      err.code
    );
  }
}