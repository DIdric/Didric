export interface CaseStudyMetric {
  label: string;
  value: string;
}

export interface CaseStudy {
  id: string;
  user_id: string;
  title: string;
  category: string;
  description: string;
  content: string;
  image_url?: string;
  year: string;
  client: string;
  metrics: CaseStudyMetric[];
  featured: boolean;
  created_at: string;
  updated_at: string;
}