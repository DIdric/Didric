import type { CaseStudy, CaseStudyMetric } from './types';

export interface ValidationError {
  field: string;
  message: string;
}

function validateMetric(metric: CaseStudyMetric): ValidationError[] {
  const errors: ValidationError[] = [];
  
  if (!metric.label?.trim()) {
    errors.push({ field: 'metrics', message: 'Metric label is required' });
  }
  if (!metric.value?.trim()) {
    errors.push({ field: 'metrics', message: 'Metric value is required' });
  }
  
  return errors;
}

export function validateCaseStudy(data: Partial<CaseStudy>): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Required fields validation
  const requiredFields = {
    title: 'Title',
    category: 'Category', 
    description: 'Description',
    content: 'Content',
    year: 'Year',
    client: 'Client'
  } as const;

  for (const [field, label] of Object.entries(requiredFields)) {
    const value = data[field as keyof typeof requiredFields];
    if (!value?.toString().trim()) {
      errors.push({
        field,
        message: `${label} is required`
      });
    }
  }

  // Metrics validation
  if (data.metrics?.length) {
    data.metrics.forEach((metric, index) => {
      const metricErrors = validateMetric(metric);
      errors.push(...metricErrors.map(error => ({
        ...error,
        message: `Metric ${index + 1}: ${error.message}`
      })));
    });
  }

  // URL validation
  if (data.image_url && !isValidUrl(data.image_url)) {
    errors.push({
      field: 'image_url',
      message: 'Please enter a valid URL'
    });
  }

  return errors;
}

function isValidUrl(url: string): boolean {
  try {
    new URL(url);
    return true;
  } catch {
    return false;
  }
}