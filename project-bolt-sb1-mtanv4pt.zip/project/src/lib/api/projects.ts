import { supabase } from '../supabase';

export interface Project {
  id: string;
  user_id: string;
  title: string;
  description: string;
  image_url?: string;
  github_url?: string;
  demo_url?: string;
  technologies?: string[];
  featured: boolean;
  created_at: string;
}

export async function getProjects() {
  const { data, error } = await supabase
    .from('projects')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data || [];
}

export async function createProject(userId: string, project: Omit<Project, 'id' | 'created_at' | 'user_id'>) {
  const { data, error } = await supabase
    .from('projects')
    .insert([{
      ...project,
      user_id: userId
    }])
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function updateProject(userId: string, projectId: string, updates: Partial<Project>) {
  const { data, error } = await supabase
    .from('projects')
    .update(updates)
    .eq('id', projectId)
    .eq('user_id', userId)
    .select()
    .single();

  if (error) throw error;
  return data;
}