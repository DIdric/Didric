import { supabase } from '../supabase';
import { createProfile } from './profiles';

export async function signIn(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password
  });

  if (error) throw error;
  
  // Ensure profile exists after sign in
  if (data.session) {
    try {
      await createProfile({
        id: data.session.user.id,
        email: data.session.user.email!,
        full_name: data.session.user.user_metadata?.full_name || data.session.user.email!.split('@')[0]
      });
    } catch (err) {
      // Ignore profile creation errors if profile already exists
      if (!err.message?.includes('duplicate key')) {
        throw err;
      }
    }
  }

  return data;
}

export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

export async function getCurrentSession() {
  const { data: { session }, error } = await supabase.auth.getSession();
  if (error) throw error;
  return session;
}