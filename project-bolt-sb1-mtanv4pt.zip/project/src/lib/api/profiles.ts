import { supabase } from '../supabase';

export interface Profile {
  id: string;
  email: string;
  full_name: string;
  headline?: string | null;
  bio?: string | null;
  avatar_url?: string | null;
  location?: string | null;
  created_at: string;
  updated_at: string;
}

export async function getProfile(userId: string) {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single();

  if (error) {
    if (error.code === 'PGRST116') {
      return null;
    }
    throw error;
  }

  return data;
}

export async function createProfile(profile: Pick<Profile, 'id' | 'email' | 'full_name'>) {
  const { data, error } = await supabase
    .from('profiles')
    .upsert([{
      ...profile,
      updated_at: new Date().toISOString()
    }])
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function updateProfile(userId: string, updates: Partial<Omit<Profile, 'id' | 'created_at'>>) {
  const { data, error } = await supabase
    .from('profiles')
    .update({
      ...updates,
      updated_at: new Date().toISOString()
    })
    .eq('id', userId)
    .select()
    .single();

  if (error) throw error;
  return data;
}